module.exports = {
    secretOrKey: "",
    MONGOURI: ""
}
